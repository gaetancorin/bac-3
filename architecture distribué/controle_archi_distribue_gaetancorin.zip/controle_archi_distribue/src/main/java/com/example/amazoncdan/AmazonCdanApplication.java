package com.example.amazoncdan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazonCdanApplication {

    public static void main(String[] args) {
        SpringApplication.run(AmazonCdanApplication.class, args);
    }

}
