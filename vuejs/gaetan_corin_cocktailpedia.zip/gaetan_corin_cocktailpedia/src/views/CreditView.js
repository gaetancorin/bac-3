const CreditView = {
  template:
`<main>
  <section>
    <header style="paddingBottom: 0">
      <h1>Page Crédit</h1>
    </header>
    <aside>
    <h3>Mettez moi une bonne note svp j'ai bosser dur</h3>
    <p>
    Site réalisé En Vue.js avec l' API :
    <a href="https://www.thecocktaildb.com/" target="_blank">
    www.thecocktaildb.com
    </a>
    </p>
    <p>
    Vidéo consigne : 
      <a href="https://www.youtube.com/watch?v=uvrrtZ_DatM" target="_blank">
        https://www.youtube.com/watch?v=uvrrtZ_DatM
      </a>
    </p>
    <p>
      Framework css : 
      <a href="https://andybrewer.github.io/mvp/" target="_blank">
        https://andybrewer.github.io/mvp/
      </a>
    </p>
    <p>
    site des emoticones : 
    <a href="https://html-css-js.com/html/character-codes/" target="_blank">
      https://html-css-js.com/html/character-codes/
    </a>
    </p>
    <p>
      Fait un DIMANCHE par Gaëtan Corin
    </p>
    </aside>
  </section>
</main>`
};

export default CreditView;
