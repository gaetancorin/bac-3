const NotFound = {
  template: "<p>404: Not Found.</p>",
};

export default NotFound;
