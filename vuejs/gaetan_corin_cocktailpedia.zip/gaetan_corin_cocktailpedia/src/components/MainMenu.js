const MainMenu = {
  template: `
  <header>
  <nav>
  <router-link to="/"> Cocktailpedia 🍹😀🍹😊🍹😐🍹🤢🍹🤮</router-link>
    <ul>
      <li><router-link to="/credit">Crédit</router-link></li>
    </ul>
  </nav>
</header>
    `,
};

export default MainMenu;
