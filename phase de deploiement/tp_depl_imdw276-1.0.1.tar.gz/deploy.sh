#! /bin/bash

CHEMINSCRIPT=$(realpath $0)
EMPLACEMENT=$(dirname $CHEMINSCRIPT)
VERSION=$(cat $EMPLACEMENT/VERSION)
echo deploy.sh version $VERSION
echo emplacement=$EMPLACEMENT
tar czf ../tp_depl_imdw276-$VERSION.tar.gz *

